# Technical decisions
I implemented my project using flask/HTML/CSS and a little javascript. The design challenges I ran into were deciding between different back-ground colors, and not being able to implement the design I planned, particularly because of difficulty in using CSS and understanding some CSS codes. The new technology/new thing I learned in this project is CSS Keyframes. I have used CSS keyframes to animate different texts  and for me it turned out to be the right tool.
# Ethical decisions
I have always wanted a website or a mobile application that recommends courses depending on the user's interest and I am glad CS 50 gave me the chance to be the change that I seek. I have had difficulties in choosing the right course and that motivated me to come up with this idea for course explorer.
# Who are the intended users?
The intended users of this website are Harvard students, both graduate and undergrads. Professors, teaching assistants and course staff members might also interact with it indirectly.
# How does your project's impact on users change as the project scales up?
As the project scales up, ideally, almost all Harvard students use it to get course recommendation. Its impact on users might change in that case because choosing courses is a very important part of people's university life and the fact that it depends on a website app makes it necessary for me to take into account the possible consequences that may result.
# Are there any types of users who might have difficulty using your project?
I think the project is implemented for everyone and the user interface is pretty basic. Visually-impaired people might have difficulty using it, given the fact that people have to interact with the website by reading/writing.
