# import os

from cs50 import SQL
from flask import Flask, redirect, render_template, request, session
from flask_session import Session

from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required

# Configure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = False

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///courses.db")




@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""
    return render_template("index.html")


@app.route("/")
@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM user WHERE username = ?", request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")

@app.route("/")
@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")
@app.route("/extracurricular")
@login_required
def extracurricular():
    return render_template("extracurricular.html")
@app.route("/discussion")
@login_required
def discussion():
    return render_template("discussion.html")
@app.route("/action_page.php",  methods=["GET", "POST"])
@login_required
def actionpage():
     if request.method == "POST":
        symbol = request.form.get("symbol")
        return render_template("page.html", symbol = symbol)


@app.route("/concentration")
@login_required
def concentration():
    return render_template("concentration.html")

@app.route("/course")
@login_required
def course():
    return render_template("course.html")
@app.route("/humanities")
@login_required
def humanities():
    return render_template("humanities.html")
@app.route("/social")
@login_required
def social():
    return render_template("social.html")
@app.route("/sciences")
@login_required
def sciences():
    return render_template("sciences.html")
@app.route("/seas")
@login_required
def seas():
    return render_template("seas.html")

@app.route("/athletics")
@login_required
def athletics():
    return render_template("athletics.html")

@app.route("/organizations")
@login_required
def organizations():
    return render_template("organizations.html")

@app.route("/rotc")
@login_required
def rotc():
    return render_template("rotc.html")

@app.route("/leadership")
@login_required
def leadership():
    return render_template("leadership.html")
@app.route("/submit" , methods=["POST"])
@login_required
def submit():
    department = request.form['department']
    difficulty = request.form['level']
    size = request.form['size']
    hour = request.form['hours']
    database = db.execute("SELECT * FROM courses WHERE department = ? AND difficulty = ? AND size = ? AND hours = ?", department, difficulty, size, hour)
    if not database:
        return render_template("defaultso.html")
    return render_template("questions.html", database = database)

@app.route("/submith" , methods=["POST"])
@login_required
def submith():
    department = request.form['department']
    difficulty = request.form['level']
    size = request.form['size']
    hour = request.form['hours']
    database = db.execute("SELECT * FROM courses WHERE department = ? AND difficulty = ? AND size = ? AND hours = ?", department, difficulty, size, hour)
    if not database:
        return render_template("defaulth.html")
    return render_template("hquestions.html", database = database)

@app.route("/submitse" , methods=["POST"])
@login_required
def submitse():
    department = request.form['department']
    difficulty = request.form['level']
    size = request.form['size']
    hour = request.form['hours']
    database = db.execute("SELECT * FROM courses WHERE department = ? AND difficulty = ? AND size = ? AND hours = ?", department, difficulty, size, hour)
    if not database:
        return render_template("default.html")
    return render_template("sequestions.html", database = database)
@app.route("/submitsc" , methods=["POST"])
@login_required
def submitsc():
    department = request.form['department']
    difficulty = request.form['level']
    size = request.form['size']
    hour = request.form['hours']
    database = db.execute("SELECT * FROM courses WHERE department = ? AND difficulty = ? AND size = ? AND hours = ?", department, difficulty, size, hour)
    if not database:
        return render_template("defaultsc.html")
    return render_template("scquestions.html", database = database)


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if not request.form.get("username"):
            return apology("must provide username", 400)
        elif not request.form.get("password"):
            return apology("must provide password", 400)
        elif not request.form.get("confirmation"):
            return apology("must provide confirmation", 400)
        elif request.form.get("password") != request.form.get("confirmation"):
            return apology("confirmation must match password")
        check = db.execute("SELECT * FROM user WHERE username = ?", request.form.get("username"))
        if len(check) == 1:
            return apology("Username already taken")

        hash_value = generate_password_hash(password)
        check = db.execute("SELECT * FROM user WHERE username = ?", request.form.get("username"))
        db.execute("INSERT INTO user (username, hash) VALUES (?, ?)", username, hash_value)
        return redirect('/')
    else:
        return render_template("register.html")




